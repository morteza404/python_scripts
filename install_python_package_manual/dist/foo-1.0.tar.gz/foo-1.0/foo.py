import random

random_list = ["reza", "ali", "morteza", "milad", "saeed"]

def choice_random_name():
    return random.choice(random_list)

print(choice_random_name())